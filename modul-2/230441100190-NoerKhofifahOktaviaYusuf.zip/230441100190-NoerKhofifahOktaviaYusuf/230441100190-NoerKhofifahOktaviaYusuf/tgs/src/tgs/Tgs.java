
/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tgs;

/**
 *
 * @author Al Fariz
 */
public class Tgs {
    private String nama;
    private String nim;
    private String alamat;
    private int jurusan;
    
    public Tgs(String nama, String nim, String alamat, int jurusan){
        this.nama = nama;
        this.nim = nim;
        this.alamat = alamat;
        this.jurusan = jurusan;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getNim(){
        return nim;
    }
    
    public void setNim(String nim){
        this.nim = nim;
    }
    
    public String getAlamat(){
        return alamat;
    }
    
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    
    public int getJurusan(){
        return jurusan;
    }
    
    public void setJurusan(int jurusan){
        this.jurusan = jurusan;
    }
    
}
