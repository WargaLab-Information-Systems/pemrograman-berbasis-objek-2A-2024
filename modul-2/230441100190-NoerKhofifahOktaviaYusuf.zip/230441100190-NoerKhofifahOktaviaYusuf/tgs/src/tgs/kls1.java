/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tgs;

/**
 *
 * @author Al Fariz
 */
public class kls1 { 
    private static String namaUniversitas;
    
    public static String getNamaUniversitas(){
        return namaUniversitas;
    }
    
    public static void setNamaUniversitas(String namaUniversitas){
        kls1.namaUniversitas = namaUniversitas;
    }
    
}
