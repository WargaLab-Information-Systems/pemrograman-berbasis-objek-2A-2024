package Main;
import java.util.Scanner;

/**
 * Main class
 * Author: adid
 */
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // objek OperasiBilanganCetak
        OperasiBilanganCetak operasiCetak = new OperasiBilanganCetak();
        
        // Membuat objek disetiap operasi 
        OperasiBilangan penjumlahan = new OperasiPenjumlahan();
        OperasiBilangan pengurangan = new OperasiPengurangan();
        OperasiBilangan perkalian = new OperasiPerkalian();
        OperasiBilangan pembagian = new OperasiPembagian();

        
        System.out.println("Pilih jenis input:");
        System.out.println("1. Masukkan 2 bilangan (A, B)");
        System.out.println("2. Masukkan 3 bilangan (A, B, C)");
        int choice = input.nextInt();
        
        
        double a, b, c;
        switch (choice) {
            case 1 -> {
                System.out.print("Masukkan nilai A: ");
                a = input.nextDouble();
                System.out.print("Masukkan nilai B: ");
                b = input.nextDouble();
                
                
                operasiCetak.cetakSemua(penjumlahan, a, b);
                operasiCetak.cetakSemua(pengurangan, a, b);
                operasiCetak.cetakSemua(perkalian, a, b);
                operasiCetak.cetakSemua(pembagian, a, b);
            }
            case 2 -> {
                System.out.print("Masukkan nilai A: ");
                a = input.nextDouble();
                System.out.print("Masukkan nilai B: ");
                b = input.nextDouble();
                System.out.print("Masukkan nilai C: ");
                c = input.nextDouble();
                
                
                operasiCetak.cetakSemua(penjumlahan, a, b, c);
                operasiCetak.cetakSemua(pengurangan, a, b, c);
                operasiCetak.cetakSemua(perkalian, a, b, c);
                operasiCetak.cetakSemua(pembagian, a, b, c);
            }
            default -> System.out.println("Pilihan tidak valid.");
        }
    }
}

