/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;


class OperasiBilanganCetak {
    void cetakSemua(OperasiBilangan operasi, double a, double b) {
        operasi.set_A(a);
        operasi.set_B(b);
        operasi.set_C(0); 
        operasi.set_D(false); 
        operasi.tampil();
    }

    void cetakSemua(OperasiBilangan operasi, double a, double b, double c) {
        operasi.set_A(a);
        operasi.set_B(b);
        operasi.set_C(c);
        operasi.set_D(true); 
        operasi.tampil();
    }
}

